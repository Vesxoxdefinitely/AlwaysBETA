# Template Manager

A modern web application for managing templates with a beautiful cloud-themed interface.

## Features

- Create, edit, and delete templates
- Search functionality for finding templates
- Modern UI with cloud animations
- Responsive design
- Local storage for data persistence
- Modal windows for template creation and viewing

## Technologies Used

- HTML5
- CSS3 (with modern features like CSS Grid, Flexbox, and Animations)
- JavaScript (ES6+)
- Font Awesome icons
- Local Storage API

## Getting Started

1. Clone the repository
2. Open `index.html` in your web browser
3. Start creating and managing your templates!

## Usage

- Click "Create New Template" to add a new template
- Use the search bar to find existing templates
- Click the eye icon to view template content
- Click the edit icon to modify a template
- Click the trash icon to delete a template

## Browser Support

The application works in all modern browsers that support:
- ES6+ JavaScript
- CSS Grid
- Flexbox
- Local Storage API

## License

MIT License 

// Отправка уведомления о начале смены
telegramSync.sendNotification('Смена начинается через 15 минут!');

// Отправка уведомления о перерыве
telegramSync.sendNotification('Перерыв начинается через 5 минут');

// Отправка расписания
telegramSync.sendNotification('Ваше расписание на сегодня:\n9:00 - Начало смены\n13:00 - Обед\n18:00 - Конец смены'); 