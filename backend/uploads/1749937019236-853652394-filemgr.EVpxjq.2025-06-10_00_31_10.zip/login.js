document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const errorMessage = document.getElementById('errorMessage');

    // Проверяем, авторизован ли пользователь
    if (localStorage.getItem('isAuthenticated')) {
        window.location.href = 'index.html';
    }

    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();

        if (!username || !password) {
            errorMessage.textContent = 'Пожалуйста, заполните все поля';
            return;
        }

        // Здесь должна быть реальная проверка авторизации
        // Для демонстрации просто сохраняем данные
        localStorage.setItem('isAuthenticated', 'true');
        localStorage.setItem('username', username);
        // Генерируем уникальный ID пользователя
        const userId = 'user_' + Math.random().toString(36).substr(2, 9);
        localStorage.setItem('userId', userId);

        // Перенаправляем на главную страницу
        window.location.href = 'index.html';
    });
}); 