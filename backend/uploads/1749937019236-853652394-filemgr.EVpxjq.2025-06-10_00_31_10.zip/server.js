const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

// Инициализация Express
const app = express();
app.use(cors());
app.use(bodyParser.json());

// Добавляем middleware для логирования запросов
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
    next();
});

// Хранилище для связи пользователей с их Telegram ID
const userConnections = new Map();
// Временное хранилище для кодов подключения
const connectionCodes = new Map();
// Временное хранилище расписаний пользователей (демо)
const userSchedules = new Map();

// API endpoint для получения расписания
app.post('/api/get-schedule', async (req, res) => {
    try {
        const { userId } = req.body;
        console.log('Получение расписания для пользователя:', userId);

        // Здесь должна быть логика получения расписания из базы данных
        // Для демонстрации возвращаем тестовые данные
        const schedule = {
            shifts: [
                {
                    date: '2024-03-20',
                    startTime: '09:00',
                    endTime: '18:00',
                    breaks: [
                        {
                            startTime: '13:00',
                            endTime: '14:00'
                        }
                    ]
                }
            ]
        };

        res.json(schedule);
    } catch (error) {
        console.error('Ошибка получения расписания:', error);
        res.status(500).json({ error: 'Внутренняя ошибка сервера' });
    }
});

// Обновляем команду /help
app.post('/api/help', async (req, res) => {
    const helpText = `
Доступные команды:
/start - Начать работу с ботом
/help - Показать это сообщение
/schedule - Показать актуальное расписание смен
/notifications - Настройки уведомлений
    `;
    res.json({ helpText });
});

// API endpoint для проверки подключения
app.post('/api/check-connection', (req, res) => {
    try {
        const { userId } = req.body;
        console.log('Проверка подключения для пользователя:', userId);
        const isConnected = userConnections.has(userId);
        console.log('Статус подключения:', isConnected);
        res.json({ connected: isConnected });
    } catch (error) {
        console.error('Ошибка проверки подключения:', error);
        res.status(500).json({ error: 'Внутренняя ошибка сервера' });
    }
});

// API endpoint для отправки уведомлений
app.post('/api/send-notification', async (req, res) => {
    try {
        const { userId, message } = req.body;
        console.log('Отправка уведомления:', { userId, message });
        
        const telegramId = userConnections.get(userId);

        if (!telegramId) {
            console.log('Пользователь не найден:', userId);
            return res.status(404).json({ error: 'Пользователь не подключен к Telegram' });
        }

        // --- Telegram Bot отключён для тестирования сайта ---
        // const bot = require('node-telegram-bot-api');
        // await bot.sendMessage(telegramId, message);
        // --- Конец блока Telegram Bot ---

        console.log('Уведомление отправлено');
        res.json({ success: true });
    } catch (error) {
        console.error('Ошибка отправки уведомления:', error);
        res.status(500).json({ error: 'Ошибка отправки уведомления' });
    }
});

// API endpoint для подключения пользователя
app.post('/api/connect-telegram', async (req, res) => {
    try {
        const { userId, connectionCode } = req.body;
        console.log('Попытка подключения:', { userId, connectionCode });
        
        if (!userId || !connectionCode) {
            console.log('Отсутствуют необходимые параметры');
            return res.status(400).json({ error: 'Необходимы userId и connectionCode' });
        }

        connectionCodes.set(userId, connectionCode);
        console.log('Код сохранен для пользователя:', userId);
        res.json({ success: true });
    } catch (error) {
        console.error('Ошибка подключения:', error);
        res.status(500).json({ error: 'Внутренняя ошибка сервера' });
    }
});

// API endpoint для отключения пользователя
app.post('/api/disconnect-telegram', async (req, res) => {
    try {
        const { userId } = req.body;
        console.log('Отключение пользователя:', userId);
        
        if (!userId) {
            return res.status(400).json({ error: 'Необходим userId' });
        }

        userConnections.delete(userId);
        console.log('Пользователь отключен:', userId);
        res.json({ success: true });
    } catch (error) {
        console.error('Ошибка отключения:', error);
        res.status(500).json({ error: 'Внутренняя ошибка сервера' });
    }
});

// API endpoint для сохранения расписания
app.post('/api/save-schedule', (req, res) => {
    try {
        const userId = req.headers['user-id'] || req.body.userId;
        const { shifts } = req.body;
        if (!userId || !shifts) {
            return res.status(400).json({ error: 'userId и shifts обязательны' });
        }
        userSchedules.set(userId, shifts);
        console.log('Сохранено расписание для пользователя:', userId, shifts);
        res.json({ success: true });
    } catch (error) {
        console.error('Ошибка сохранения расписания:', error);
        res.status(500).json({ error: 'Внутренняя ошибка сервера' });
    }
});

// Запуск сервера
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Сервер запущен на порту ${PORT}`);
    // console.log('Токен бота:', token);
}); 