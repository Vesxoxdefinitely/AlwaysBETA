// Create clouds
function createClouds() {
    const cloudsContainer = document.querySelector('.clouds');
    for (let i = 0; i < 5; i++) {
        const cloud = document.createElement('div');
        cloud.className = 'cloud';
        cloud.style.setProperty('--scale', (0.8 + Math.random() * 0.4).toFixed(2));
        cloudsContainer.appendChild(cloud);
    }
}

// Tab Management
class TabManager {
    constructor() {
        this.initializeTabs();
    }

    initializeTabs() {
        const tabs = document.querySelectorAll('.main-nav li');
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                this.switchTab(tab.dataset.tab);
            });
        });
    }

    switchTab(tabId) {
        // Update active tab
        document.querySelectorAll('.main-nav li').forEach(tab => {
            tab.classList.remove('active');
            if (tab.dataset.tab === tabId) {
                tab.classList.add('active');
            }
        });

        // Show active content
        document.querySelectorAll('.tab-pane').forEach(pane => {
            pane.classList.remove('active');
            if (pane.id === tabId) {
                pane.classList.add('active');
            }
        });
    }
}

// Template Management
class TemplateManager {
    constructor() {
        this.templates = JSON.parse(localStorage.getItem('templates')) || [];
        this.currentTemplateId = null;
        this.initializeEventListeners();
        this.renderTemplates();
    }

    initializeEventListeners() {
        // Create template button
        document.getElementById('createTemplateBtn').addEventListener('click', () => {
            this.openModal('templateModal');
        });

        // Search functionality
        document.getElementById('searchInput').addEventListener('input', (e) => {
            this.filterTemplates(e.target.value);
        });

        // Modal close buttons
        document.querySelectorAll('.close').forEach(btn => {
            btn.addEventListener('click', () => {
                this.closeAllModals();
            });
        });

        // Template form submission
        document.getElementById('templateForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveTemplate();
        });

        // Close modals when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeAllModals();
            }
        });
    }

    openModal(modalId) {
        document.getElementById(modalId).style.display = 'block';
    }

    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.style.display = 'none';
        });
        this.currentTemplateId = null;
        document.getElementById('templateForm').reset();
    }

    saveTemplate() {
        const name = document.getElementById('templateName').value;
        const content = document.getElementById('templateContent').value;

        if (this.currentTemplateId) {
            // Update existing template
            const index = this.templates.findIndex(t => t.id === this.currentTemplateId);
            this.templates[index] = { id: this.currentTemplateId, name, content };
        } else {
            // Create new template
            const newTemplate = {
                id: Date.now(),
                name,
                content
            };
            this.templates.push(newTemplate);
        }

        this.saveToLocalStorage();
        this.renderTemplates();
        this.closeAllModals();
    }

    deleteTemplate(id) {
        if (confirm('Вы уверены, что хотите удалить этот шаблон?')) {
            this.templates = this.templates.filter(t => t.id !== id);
            this.saveToLocalStorage();
            this.renderTemplates();
        }
    }

    editTemplate(id) {
        const template = this.templates.find(t => t.id === id);
        if (template) {
            this.currentTemplateId = id;
            document.getElementById('templateName').value = template.name;
            document.getElementById('templateContent').value = template.content;
            this.openModal('templateModal');
        }
    }

    viewTemplate(id) {
        const template = this.templates.find(t => t.id === id);
        if (template) {
            document.getElementById('viewTemplateTitle').textContent = template.name;
            document.getElementById('viewTemplateContent').textContent = template.content;
            this.openModal('viewModal');
        }
    }

    filterTemplates(searchTerm) {
        const filteredTemplates = this.templates.filter(template =>
            template.name.toLowerCase().includes(searchTerm.toLowerCase())
        );
        this.renderTemplates(filteredTemplates);
    }

    renderTemplates(templatesToRender = this.templates) {
        const container = document.getElementById('templatesContainer');
        container.innerHTML = '';

        templatesToRender.forEach(template => {
            const templateCard = document.createElement('div');
            templateCard.className = 'template-card';
            templateCard.innerHTML = `
                <h3>${template.name}</h3>
                <div class="template-actions">
                    <button class="btn icon-btn" onclick="templateManager.viewTemplate(${template.id})" title="Просмотр">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn icon-btn" onclick="templateManager.editTemplate(${template.id})" title="Редактировать">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn icon-btn" onclick="templateManager.copyTemplate(${template.id})" title="Копировать">
                        <i class="fas fa-copy"></i>
                    </button>
                    <button class="btn icon-btn" onclick="templateManager.deleteTemplate(${template.id})" title="Удалить">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
            container.appendChild(templateCard);
        });
    }

    copyTemplate(id) {
        const template = this.templates.find(t => t.id === id);
        if (template) {
            const textToCopy = `${template.name}\n\n${template.content}`;
            navigator.clipboard.writeText(textToCopy).then(() => {
                this.showCopyNotification();
            }).catch(err => {
                console.error('Ошибка при копировании:', err);
            });
        }
    }

    showCopyNotification() {
        // Создаем уведомление о копировании
        const notification = document.createElement('div');
        notification.className = 'copy-notification';
        notification.innerHTML = `
            <i class="fas fa-check"></i>
            <span>Шаблон скопирован в буфер обмена</span>
        `;
        document.body.appendChild(notification);

        // Показываем уведомление
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);

        // Удаляем уведомление через 2 секунды
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 2000);
    }

    saveToLocalStorage() {
        localStorage.setItem('templates', JSON.stringify(this.templates));
    }
}

// Schedule functionality
class ScheduleManager {
    constructor() {
        this.selectedDate = null;
        this.shifts = new Map();
        
        // Schedule elements
        this.selectedDateEl = document.getElementById('selectedDate');
        this.editShiftBtn = document.getElementById('editShiftBtn');
        this.deleteShiftBtn = document.getElementById('deleteShiftBtn');
        this.addShiftBtn = document.getElementById('addShiftBtn');
        this.syncScheduleBtn = document.getElementById('syncScheduleBtn');
        
        // Timeline elements
        this.timelineContainer = document.getElementById('timelineContainer');
        this.currentTimeEl = document.getElementById('currentTime');
        this.shiftStatusEl = document.getElementById('shiftStatus');
        this.currentTimeIndicator = document.getElementById('currentTimeIndicator');
        
        // Summary elements
        this.shiftDurationEl = document.getElementById('shiftDuration');
        this.timeElapsedEl = document.getElementById('timeElapsed');
        this.timeRemainingEl = document.getElementById('timeRemaining');
        this.breaksCountEl = document.getElementById('breaksCount');
        this.totalBreakTimeEl = document.getElementById('totalBreakTime');
        
        // Modal elements
        this.shiftModal = document.getElementById('shiftModal');
        this.modalTitle = document.getElementById('modalTitle');
        this.shiftForm = document.getElementById('shiftForm');
        this.shiftDateInput = document.getElementById('shiftDate');
        this.shiftStartInput = document.getElementById('shiftStart');
        this.shiftEndInput = document.getElementById('shiftEnd');
        this.breaksList = document.getElementById('breaksList');
        this.addBreakBtn = document.getElementById('addBreakBtn');
        this.saveShiftBtn = document.getElementById('saveShiftBtn');
        this.breakTemplate = document.getElementById('breakTemplate');
        
        this.initializeEventListeners();
        this.loadSchedule();
        this.startTimeUpdates();
    }

    initializeEventListeners() {
        // Schedule actions
        this.addShiftBtn?.addEventListener('click', () => this.openShiftModal());
        this.editShiftBtn?.addEventListener('click', () => this.openShiftModal(true));
        this.deleteShiftBtn?.addEventListener('click', () => this.deleteShift());
        this.syncScheduleBtn?.addEventListener('click', () => this.syncSchedule());
        
        // Modal actions
        this.shiftForm?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveShift();
        });
        this.addBreakBtn?.addEventListener('click', () => this.addBreak());
        this.saveShiftBtn?.addEventListener('click', () => this.saveShift());
        
        // Close modal buttons
        document.querySelectorAll('.close-modal').forEach(btn => {
            btn.addEventListener('click', () => this.closeShiftModal());
        });
        
        // Close modal on outside click
        this.shiftModal?.addEventListener('click', (e) => {
            if (e.target === this.shiftModal) {
                this.closeShiftModal();
            }
        });
    }

    startTimeUpdates() {
        setInterval(() => this.updateCurrentTime(), 1000);
        this.updateCurrentTime();
    }

    updateCurrentTime() {
        const now = new Date();
        if (this.currentTimeEl) {
            this.currentTimeEl.textContent = this.formatTime(now);
        }
        
        if (this.selectedDate && this.isShiftActive()) {
            this.updateTimeline();
        }
    }

    isShiftActive() {
        if (!this.selectedDate) return false;
        
        const shift = this.shifts.get(this.formatDate(this.selectedDate));
        if (!shift) return false;
        
        const now = new Date();
        const currentTime = now.getHours() * 60 + now.getMinutes();
        const startTime = this.timeToMinutes(shift.start);
        const endTime = this.timeToMinutes(shift.end);
        
        return currentTime >= startTime && currentTime <= endTime;
    }

    updateTimeline() {
        if (!this.timelineContainer || !this.selectedDate) return;
        
        const shift = this.shifts.get(this.formatDate(this.selectedDate));
        if (!shift) {
            this.clearTimeline();
            return;
        }
        
        const startTime = this.timeToMinutes(shift.start);
        const endTime = this.timeToMinutes(shift.end);
        const totalDuration = endTime - startTime;
        
        // Update summary
        if (this.shiftDurationEl) {
            this.shiftDurationEl.textContent = `${Math.floor(totalDuration / 60)}ч ${totalDuration % 60}м`;
        }
        
        // Update breaks count and total time
        const totalBreakTime = shift.breaks.reduce((sum, break_) => sum + break_.duration, 0);
        if (this.breaksCountEl) {
            this.breaksCountEl.textContent = shift.breaks.length;
        }
        if (this.totalBreakTimeEl) {
            this.totalBreakTimeEl.textContent = `${totalBreakTime} мин`;
        }
        
        // Update timeline visualization
        this.renderTimeline(startTime, endTime, shift.breaks);
        
        // Update progress and status
        this.updateProgress(startTime, endTime);
    }

    clearTimeline() {
        if (!this.timelineContainer) return;
        
        const scaleEl = this.timelineContainer.querySelector('.timeline-scale');
        const eventsEl = this.timelineContainer.querySelector('.timeline-events');
        
        if (scaleEl) scaleEl.innerHTML = '';
        if (eventsEl) eventsEl.innerHTML = '';
        
        if (this.shiftStatusEl) {
            this.shiftStatusEl.textContent = 'Нет активной смены';
        }
        
        if (this.currentTimeIndicator) {
            this.currentTimeIndicator.style.display = 'none';
        }
        
        // Clear summary
        if (this.shiftDurationEl) this.shiftDurationEl.textContent = '0ч 0м';
        if (this.timeElapsedEl) this.timeElapsedEl.textContent = '0ч 0м';
        if (this.timeRemainingEl) this.timeRemainingEl.textContent = '0ч 0м';
        if (this.breaksCountEl) this.breaksCountEl.textContent = '0';
        if (this.totalBreakTimeEl) this.totalBreakTimeEl.textContent = '0 мин';
    }

    renderTimeline(start, end, breaks) {
        if (!this.timelineContainer) return;
        
        const scaleEl = this.timelineContainer.querySelector('.timeline-scale');
        const eventsEl = this.timelineContainer.querySelector('.timeline-events');
        
        if (!scaleEl || !eventsEl) return;
        
        // Clear existing markers
        scaleEl.innerHTML = '';
        eventsEl.innerHTML = '';
        
        // Create time markers
        for (let time = start; time <= end; time += 30) {
            const marker = document.createElement('div');
            marker.className = 'timeline-marker';
            marker.style.left = `${((time - start) / (end - start)) * 100}%`;
            marker.innerHTML = `<span>${this.minutesToTime(time)}</span>`;
            scaleEl.appendChild(marker);
        }
        
        // Add break markers
        breaks.forEach(break_ => {
            const breakMarker = document.createElement('div');
            breakMarker.className = 'timeline-break';
            breakMarker.style.left = `${((this.timeToMinutes(break_.start) - start) / (end - start)) * 100}%`;
            breakMarker.style.width = `${(break_.duration / (end - start)) * 100}%`;
            eventsEl.appendChild(breakMarker);
        });
    }

    updateProgress(startTime, endTime) {
        const now = new Date();
        const currentTime = now.getHours() * 60 + now.getMinutes();
        const totalDuration = endTime - startTime;
        const elapsed = Math.max(0, Math.min(totalDuration, currentTime - startTime));
        const remaining = totalDuration - elapsed;
        
        // Update time labels
        if (this.timeElapsedEl) {
            this.timeElapsedEl.textContent = `${Math.floor(elapsed / 60)}ч ${elapsed % 60}м`;
        }
        
        if (this.timeRemainingEl) {
            this.timeRemainingEl.textContent = `${Math.floor(remaining / 60)}ч ${remaining % 60}м`;
        }
        
        // Update status
        if (this.shiftStatusEl) {
            if (currentTime < startTime) {
                this.shiftStatusEl.textContent = 'Не начата';
            } else if (currentTime > endTime) {
                this.shiftStatusEl.textContent = 'Завершена';
            } else {
                this.shiftStatusEl.textContent = 'В процессе';
            }
        }
        
        // Update current time indicator
        if (this.currentTimeIndicator) {
            if (currentTime >= startTime && currentTime <= endTime) {
                this.currentTimeIndicator.style.display = 'block';
                const position = ((currentTime - startTime) / totalDuration) * 100;
                this.currentTimeIndicator.style.left = `${position}%`;
            } else {
                this.currentTimeIndicator.style.display = 'none';
            }
        }
    }

    openShiftModal(isEdit = false) {
        if (!this.shiftModal || !this.modalTitle) return;
        
        this.modalTitle.textContent = isEdit ? 'Редактировать смену' : 'Добавить смену';
        
        if (isEdit && this.selectedDate) {
            const shift = this.shifts.get(this.formatDate(this.selectedDate));
            if (shift) {
                this.shiftDateInput.value = this.formatDate(this.selectedDate);
                this.shiftStartInput.value = shift.start;
                this.shiftEndInput.value = shift.end;
                
                // Clear existing breaks
                this.breaksList.innerHTML = '';
                
                // Add breaks
                shift.breaks.forEach(break_ => {
                    this.addBreak(break_.start, break_.duration);
                });
            }
        } else {
            this.shiftForm.reset();
            this.breaksList.innerHTML = '';
        }
        
        this.shiftModal.classList.add('active');
    }

    closeShiftModal() {
        if (this.shiftModal) {
            this.shiftModal.classList.remove('active');
        }
    }

    addBreak(start = '', duration = 30) {
        if (!this.breakTemplate || !this.breaksList) return;
        
        const breakItem = this.breakTemplate.cloneNode(true);
        breakItem.id = '';
        breakItem.style.display = 'grid';
        
        const startInput = breakItem.querySelector('.break-start');
        const durationInput = breakItem.querySelector('.break-duration');
        const removeBtn = breakItem.querySelector('.remove-break');
        
        if (startInput) startInput.value = start;
        if (durationInput) durationInput.value = duration;
        
        if (removeBtn) {
            removeBtn.addEventListener('click', () => breakItem.remove());
        }
        
        this.breaksList.appendChild(breakItem);
    }

    async saveShift() {
        if (!this.shiftForm || !this.shiftDateInput || !this.shiftStartInput || !this.shiftEndInput) return;
        
        const shift = {
            date: this.shiftDateInput.value,
            startTime: this.shiftStartInput.value,
            endTime: this.shiftEndInput.value,
            breaks: Array.from(this.breaksList.querySelectorAll('.break-item:not(#breakTemplate)'))
                .map(item => ({
                    startTime: item.querySelector('.break-start')?.value,
                    endTime: this.calculateBreakEndTime(
                        item.querySelector('.break-start')?.value,
                        parseInt(item.querySelector('.break-duration')?.value)
                    )
                }))
                .filter(break_ => break_.startTime && break_.endTime)
        };
        
        try {
            const response = await fetch('/api/save-schedule', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'user-id': localStorage.getItem('userId')
                },
                body: JSON.stringify({ shifts: [shift] })
            });
            
            if (response.ok) {
                this.shifts.set(shift.date, shift);
                this.updateTimeline();
                this.closeShiftModal();
                this.showNotification('Смена успешно сохранена', 'success');
            } else {
                throw new Error('Ошибка при сохранении смены');
            }
        } catch (error) {
            this.showNotification(error.message, 'error');
        }
    }

    calculateBreakEndTime(startTime, duration) {
        if (!startTime || !duration) return null;
        const [hours, minutes] = startTime.split(':').map(Number);
        const totalMinutes = hours * 60 + minutes + duration;
        const endHours = Math.floor(totalMinutes / 60);
        const endMinutes = totalMinutes % 60;
        return `${endHours.toString().padStart(2, '0')}:${endMinutes.toString().padStart(2, '0')}`;
    }

    async deleteShift() {
        if (!this.selectedDate) return;
        
        const date = this.formatDate(this.selectedDate);
        if (!this.shifts.has(date)) return;
        
        try {
            const response = await fetch('/api/delete-schedule', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'user-id': localStorage.getItem('userId')
                },
                body: JSON.stringify({ date })
            });
            
            if (response.ok) {
                this.shifts.delete(date);
                this.updateTimeline();
                this.showNotification('Смена успешно удалена', 'success');
            } else {
                throw new Error('Ошибка при удалении смены');
            }
        } catch (error) {
            this.showNotification(error.message, 'error');
        }
    }

    async syncSchedule() {
        try {
            const response = await fetch('/api/sync-schedule', {
                method: 'POST',
                headers: {
                    'user-id': localStorage.getItem('userId')
                }
            });
            
            if (response.ok) {
                const schedule = await response.json();
                this.loadScheduleData(schedule);
                this.showNotification('Расписание синхронизировано', 'success');
            } else {
                throw new Error('Ошибка при синхронизации расписания');
            }
        } catch (error) {
            this.showNotification(error.message, 'error');
        }
    }

    async loadSchedule() {
        try {
            const response = await fetch('/api/get-schedule', {
                headers: {
                    'user-id': localStorage.getItem('userId')
                }
            });
            
            if (response.ok) {
                const schedule = await response.json();
                this.loadScheduleData(schedule);
            }
        } catch (error) {
            console.error('Error loading schedule:', error);
        }
    }

    loadScheduleData(schedule) {
        if (!schedule) return;
        
        this.shifts.clear();
        
        if (Array.isArray(schedule)) {
            schedule.forEach(shift => {
                this.shifts.set(shift.date, shift);
            });
        }
        
        if (this.selectedDate) {
            this.updateTimeline();
        }
    }

    formatDate(date) {
        return date.toISOString().split('T')[0];
    }

    formatTime(date) {
        return `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
    }

    timeToMinutes(time) {
        if (!time) return 0;
        const [hours, minutes] = time.split(':').map(Number);
        return hours * 60 + minutes;
    }

    minutesToTime(minutes) {
        const hours = Math.floor(minutes / 60);
        const mins = minutes % 60;
        return `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`;
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
}

// Initialize schedule manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const scheduleManager = new ScheduleManager();
});

// Hall of Fame Management
class HallOfFameManager {
    constructor() {
        this.achievements = [
            {
                id: 1,
                title: "Первые шаги",
                description: "Создайте свой первый шаблон",
                icon: "fa-file-alt",
                image: "placeholder.jpg",
                progress: 0,
                locked: true
            },
            {
                id: 2,
                title: "Мастер расписания",
                description: "Настройте полное расписание рабочего дня",
                icon: "fa-clock",
                image: "placeholder.jpg",
                progress: 0,
                locked: true
            },
            {
                id: 3,
                title: "Организатор",
                description: "Создайте 5 различных шаблонов",
                icon: "fa-tasks",
                image: "placeholder.jpg",
                progress: 0,
                locked: true
            },
            {
                id: 4,
                title: "Время на отдых",
                description: "Добавьте 3 перерыва в расписание",
                icon: "fa-coffee",
                image: "placeholder.jpg",
                progress: 0,
                locked: true
            },
            {
                id: 5,
                title: "Поисковик",
                description: "Используйте поиск шаблонов 5 раз",
                icon: "fa-search",
                image: "placeholder.jpg",
                progress: 0,
                locked: true
            },
            {
                id: 6,
                title: "Редактор",
                description: "Отредактируйте существующий шаблон",
                icon: "fa-edit",
                image: "placeholder.jpg",
                progress: 0,
                locked: true
            },
            {
                id: 7,
                title: "Планировщик",
                description: "Настройте расписание на всю неделю",
                icon: "fa-calendar-week",
                image: "placeholder.jpg",
                progress: 0,
                locked: true
            },
            {
                id: 8,
                title: "Эксперт",
                description: "Достигните 100% эффективности в работе",
                icon: "fa-chart-line",
                image: "placeholder.jpg",
                progress: 0,
                locked: true
            },
            {
                id: 9,
                title: "Мастер настройки",
                description: "Настройте все параметры приложения",
                icon: "fa-sliders-h",
                image: "placeholder.jpg",
                progress: 0,
                locked: true
            },
            {
                id: 10,
                title: "Легенда",
                description: "Разблокируйте все достижения",
                icon: "fa-crown",
                image: "placeholder.jpg",
                progress: 0,
                locked: true
            }
        ];
        this.initializeHallOfFame();
    }

    initializeHallOfFame() {
        this.renderAchievements();
        this.updateStats();
    }

    renderAchievements() {
        const grid = document.getElementById('achievementsGrid');
        grid.innerHTML = '';

        this.achievements.forEach(achievement => {
            const card = document.createElement('div');
            card.className = `achievement-card ${achievement.locked ? 'locked' : ''}`;
            card.innerHTML = `
                <div class="achievement-image">
                    <img src="${achievement.image}" alt="${achievement.title}">
                </div>
                <div class="achievement-content">
                    <h3 class="achievement-title">
                        <i class="fas ${achievement.icon}"></i>
                        ${achievement.title}
                    </h3>
                    <p class="achievement-description">${achievement.description}</p>
                    <div class="achievement-progress">
                        <div class="achievement-progress-bar" style="width: ${achievement.progress}%"></div>
                    </div>
                </div>
                <div class="achievement-locked">
                    <i class="fas fa-lock"></i>
                </div>
            `;
            grid.appendChild(card);
        });
    }

    updateStats() {
        const achieved = this.achievements.filter(a => !a.locked).length;
        const total = this.achievements.length;
        const progress = Math.round((achieved / total) * 100);

        document.getElementById('achievedCount').textContent = achieved;
        document.getElementById('totalProgress').textContent = progress;
    }

    unlockAchievement(id) {
        const achievement = this.achievements.find(a => a.id === id);
        if (achievement && achievement.locked) {
            achievement.locked = false;
            achievement.progress = 100;
            this.renderAchievements();
            this.updateStats();
            this.showUnlockNotification(achievement);
        }
    }

    updateProgress(id, progress) {
        const achievement = this.achievements.find(a => a.id === id);
        if (achievement) {
            achievement.progress = Math.min(100, progress);
            if (achievement.progress === 100) {
                this.unlockAchievement(id);
            } else {
                this.renderAchievements();
            }
        }
    }

    showUnlockNotification(achievement) {
        // Здесь можно добавить красивое уведомление о разблокировке ачивки
        console.log(`Достижение разблокировано: ${achievement.title}`);
    }
}

class CabinetManager {
    constructor() {
        this.currentDate = new Date();
        this.absences = this.loadAbsences();
        this.currentAbsence = null;
        this.isEditing = false;
        this.initializeCabinet();
    }

    initializeCabinet() {
        this.loadUserData();
        this.setupAvatarUpload();
        this.setupNameInputs();
        this.renderCalendar();
        // Добавляю обработчики для кнопок управления отсутствием
        const editBtn = document.getElementById('editAbsence');
        const deleteBtn = document.getElementById('deleteAbsence');
        if (editBtn) {
            editBtn.onclick = () => this.startEditing();
        }
        if (deleteBtn) {
            deleteBtn.onclick = () => this.deleteAbsence();
        }
        // Открытие выбора файла по клику на аватар
        const avatarContainer = document.querySelector('.avatar-container');
        const avatarInput = document.getElementById('avatarInput');
        if (avatarContainer && avatarInput) {
            avatarContainer.addEventListener('click', () => avatarInput.click());
        }
    }

    loadAbsences() {
        try {
            return JSON.parse(localStorage.getItem('absences')) || [];
        } catch (error) {
            console.error('Ошибка загрузки отсутствий:', error);
            return [];
        }
    }

    saveAbsences() {
        try {
            localStorage.setItem('absences', JSON.stringify(this.absences));
        } catch (error) {
            console.error('Ошибка сохранения отсутствий:', error);
        }
    }

    renderCalendar() {
        const year = this.currentDate.getFullYear();
        const month = this.currentDate.getMonth();
        
        // Обновляем заголовок
        const monthNames = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 
                          'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
        document.getElementById('currentMonth').textContent = `${monthNames[month]} ${year}`;

        // Получаем первый день месяца и количество дней
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const daysInMonth = lastDay.getDate();
        
        // Получаем день недели первого дня (0 - воскресенье, 1 - понедельник, ...)
        let firstDayOfWeek = firstDay.getDay();
        if (firstDayOfWeek === 0) firstDayOfWeek = 7; // Преобразуем воскресенье в 7
        
        // Создаем сетку календаря
        const calendarDays = document.getElementById('calendarDays');
        calendarDays.innerHTML = '';

        // Добавляем пустые ячейки для дней предыдущего месяца
        for (let i = 1; i < firstDayOfWeek; i++) {
            const emptyDay = document.createElement('div');
            emptyDay.className = 'calendar-day other-month';
            calendarDays.appendChild(emptyDay);
        }

        // Добавляем дни текущего месяца
        const today = new Date();
        for (let day = 1; day <= daysInMonth; day++) {
            const dayElement = document.createElement('div');
            dayElement.className = 'calendar-day';
            dayElement.textContent = day;

            // Отмечаем текущий день
            if (day === today.getDate() && month === today.getMonth() && year === today.getFullYear()) {
                dayElement.classList.add('today');
            }

            // Проверяем отсутствия на этот день
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const absence = this.absences.find(a => {
                const start = new Date(a.start);
                const end = new Date(a.end);
                const current = new Date(dateStr);
                return current >= start && current <= end;
            });

            if (absence) {
                dayElement.classList.add('has-absence', absence.type);
                // Добавляем атрибут с подсказкой
                const tooltipText = {
                    'vacation': 'Отпуск',
                    'day-off': 'Отгул',
                    'sick': 'Болезнь'
                }[absence.type];
                dayElement.setAttribute('data-tooltip', tooltipText);
                
                // Добавляем обработчик двойного клика для редактирования
                dayElement.addEventListener('dblclick', (e) => {
                    e.stopPropagation();
                    this.showAbsenceModal(null, null, absence.id);
                });
            }

            // Добавляем обработчик клика для создания/просмотра отсутствия
            dayElement.addEventListener('click', () => {
                const existingAbsence = this.findAbsenceForDate(dateStr);
                if (existingAbsence) {
                    this.showAbsenceModal(null, null, existingAbsence.id);
                } else {
                    this.showAbsenceModal(null, dateStr);
                }
            });
            
            calendarDays.appendChild(dayElement);
        }
    }

    prevMonth() {
        this.currentDate.setMonth(this.currentDate.getMonth() - 1);
        this.renderCalendar();
    }

    nextMonth() {
        this.currentDate.setMonth(this.currentDate.getMonth() + 1);
        this.renderCalendar();
    }

    showAbsenceModal(type = null, date = null, absenceId = null) {
        const modal = document.getElementById('absenceModal');
        const typeSelect = document.getElementById('absenceType');
        const startInput = document.getElementById('absenceStart');
        const endInput = document.getElementById('absenceEnd');
        const commentInput = document.getElementById('absenceComment');
        const editButton = document.getElementById('editAbsence');
        const deleteButton = document.getElementById('deleteAbsence');
        const saveButton = document.getElementById('saveAbsence');

        // Сбрасываем состояние
        this.currentAbsence = null;
        this.isEditing = false;
        this.toggleEditing(false);

        if (absenceId) {
            // Режим просмотра существующего отсутствия
            const absence = this.absences.find(a => a.id === absenceId);
            if (absence) {
                this.currentAbsence = absence;
                typeSelect.value = absence.type;
                startInput.value = absence.start;
                endInput.value = absence.end;
                commentInput.value = absence.comment || '';
                editButton.style.display = 'flex';
                deleteButton.style.display = 'flex';
            }
        } else {
            // Режим создания нового отсутствия
            if (type) {
                typeSelect.value = type;
            }

            // Проверяем, есть ли уже существующее отсутствие на выбранную дату
            if (date) {
                const existingAbsence = this.findAbsenceForDate(date);
                if (existingAbsence) {
                    // Если нашли существующее отсутствие, показываем его
                    this.currentAbsence = existingAbsence;
                    typeSelect.value = existingAbsence.type;
                    startInput.value = existingAbsence.start;
                    endInput.value = existingAbsence.end;
                    commentInput.value = existingAbsence.comment || '';
                    editButton.style.display = 'flex';
                    deleteButton.style.display = 'flex';
                } else {
                    // Если отсутствия нет, создаем новое
                    startInput.value = date;
                    endInput.value = date;
                    commentInput.value = '';
                    editButton.style.display = 'none';
                    deleteButton.style.display = 'none';
                    this.toggleEditing(true);
                }
            }
        }

        modal.style.display = 'flex';
    }

    findAbsenceForDate(date) {
        return this.absences.find(absence => {
            const start = new Date(absence.start);
            const end = new Date(absence.end);
            const current = new Date(date);
            return current >= start && current <= end;
        });
    }

    toggleEditing(enable) {
        const typeSelect = document.getElementById('absenceType');
        const startInput = document.getElementById('absenceStart');
        const endInput = document.getElementById('absenceEnd');
        const commentInput = document.getElementById('absenceComment');
        const editButton = document.getElementById('editAbsence');
        const saveButton = document.getElementById('saveAbsence');

        this.isEditing = enable;
        
        // Включаем/выключаем поля ввода
        typeSelect.disabled = !enable;
        startInput.disabled = !enable;
        endInput.disabled = !enable;
        commentInput.disabled = !enable;

        // Показываем/скрываем кнопки
        editButton.style.display = enable ? 'none' : 'flex';
        saveButton.style.display = enable ? 'block' : 'none';
    }

    startEditing() {
        this.toggleEditing(true);
    }

    closeAbsenceModal() {
        const modal = document.getElementById('absenceModal');
        modal.style.display = 'none';
        this.currentAbsence = null;
        this.isEditing = false;
    }

    saveAbsence() {
        const type = document.getElementById('absenceType').value;
        const start = document.getElementById('absenceStart').value;
        const end = document.getElementById('absenceEnd').value;
        const comment = document.getElementById('absenceComment').value;

        if (!start || !end) {
            alert('Пожалуйста, выберите даты начала и окончания');
            return;
        }

        if (new Date(start) > new Date(end)) {
            alert('Дата начала не может быть позже даты окончания');
            return;
        }

        const absenceData = {
            type,
            start,
            end,
            comment,
            userId: this.getUserId()
        };

        if (this.currentAbsence) {
            // Обновление существующего отсутствия
            const index = this.absences.findIndex(a => a.id === this.currentAbsence.id);
            if (index !== -1) {
                this.absences[index] = { ...this.absences[index], ...absenceData };
            }
        } else {
            // Создание нового отсутствия
            absenceData.id = this.generateAbsenceId();
            this.absences.push(absenceData);
        }

        this.saveAbsences();
        this.renderCalendar();
        this.closeAbsenceModal();
    }

    deleteAbsence() {
        if (!this.currentAbsence) return;

        if (confirm('Вы уверены, что хотите удалить это отсутствие?')) {
            this.absences = this.absences.filter(a => a.id !== this.currentAbsence.id);
            this.saveAbsences();
            this.renderCalendar();
            this.closeAbsenceModal();
        }
    }

    generateAbsenceId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    getUserId() {
        // В реальном приложении здесь будет получение ID текущего пользователя
        return 'current-user';
    }

    loadUserData() {
        const userData = JSON.parse(localStorage.getItem('userData')) || {
            name: '',
            surname: '',
            avatar: 'https://via.placeholder.com/150'
        };

        document.getElementById('userName').value = userData.name;
        document.getElementById('userSurname').value = userData.surname;
        document.getElementById('userAvatar').src = userData.avatar;
    }

    setupAvatarUpload() {
        const avatarInput = document.getElementById('avatarInput');
        const avatarImg = document.getElementById('userAvatar');

        avatarInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    avatarImg.src = e.target.result;
                    this.saveUserData();
                };
                reader.readAsDataURL(file);
            }
        });
    }

    setupNameInputs() {
        const nameInput = document.getElementById('userName');
        const surnameInput = document.getElementById('userSurname');

        const saveTimeout = (input) => {
            clearTimeout(input.timeout);
            input.timeout = setTimeout(() => this.saveUserData(), 500);
        };

        nameInput.addEventListener('input', () => saveTimeout(nameInput));
        surnameInput.addEventListener('input', () => saveTimeout(surnameInput));
    }

    saveUserData() {
        const userData = {
            name: document.getElementById('userName').value,
            surname: document.getElementById('userSurname').value,
            avatar: document.getElementById('userAvatar').src
        };
        localStorage.setItem('userData', JSON.stringify(userData));
    }
}

// Функционал переключения темы
const themeToggle = document.getElementById('themeToggle');
const themeIcon = themeToggle.querySelector('.theme-icon');

// Проверяем сохраненную тему
const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'dark') {
    document.body.classList.add('dark-theme');
    themeIcon.textContent = '☀️';
}

// Обработчик переключения темы
themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-theme');
    
    // Обновляем иконку
    if (document.body.classList.contains('dark-theme')) {
        themeIcon.textContent = '☀️';
        localStorage.setItem('theme', 'dark');
    } else {
        themeIcon.textContent = '🌙';
        localStorage.setItem('theme', 'light');
    }
    
    // Добавляем анимацию
    themeIcon.style.animation = 'none';
    themeIcon.offsetHeight; // Форсируем перерисовку
    themeIcon.style.animation = 'rotate 0.5s ease';
});

// Функционал для работы с эмодзи и счетчиком символов
const emojiButton = document.querySelector('.emoji-button');
const emojiList = document.querySelector('.emoji-list');
const statusInput = document.getElementById('userStatus');
const charCount = document.getElementById('charCount');
const charCounter = document.querySelector('.char-counter');
const MAX_CHARS = 39;

// Обновление счетчика символов
function updateCharCount() {
    const currentLength = statusInput.value.length;
    charCount.textContent = currentLength;
    
    // Добавляем класс warning, если осталось мало символов
    if (currentLength >= MAX_CHARS - 5) {
        charCounter.classList.add('warning');
    } else {
        charCounter.classList.remove('warning');
    }
    
    // Обновляем состояние кнопки эмодзи
    if (currentLength >= MAX_CHARS) {
        emojiButton.style.opacity = '0.5';
        emojiButton.style.cursor = 'not-allowed';
    } else {
        emojiButton.style.opacity = '1';
        emojiButton.style.cursor = 'pointer';
    }
}

// Показать/скрыть список эмодзи
emojiButton.addEventListener('click', (e) => {
    e.stopPropagation();
    if (statusInput.value.length < MAX_CHARS) {
        emojiList.style.display = emojiList.style.display === 'none' ? 'grid' : 'none';
    }
});

// Закрыть список эмодзи при клике вне его
document.addEventListener('click', (e) => {
    if (!emojiList.contains(e.target) && e.target !== emojiButton) {
        emojiList.style.display = 'none';
    }
});

// Добавление эмодзи в статус
emojiList.addEventListener('click', (e) => {
    if (e.target.tagName === 'SPAN') {
        const emoji = e.target.textContent;
        const cursorPos = statusInput.selectionStart;
        const text = statusInput.value;
        const newText = text.slice(0, cursorPos) + emoji + text.slice(cursorPos);
        
        if (newText.length <= MAX_CHARS) {
            statusInput.value = newText;
            statusInput.focus();
            statusInput.setSelectionRange(cursorPos + emoji.length, cursorPos + emoji.length);
            updateCharCount();
        }
        
        emojiList.style.display = 'none';
    }
});

// Обновление счетчика при вводе
statusInput.addEventListener('input', updateCharCount);

// Инициализация счетчика
updateCharCount();

// Telegram Sync Manager
class TelegramSyncManager {
    constructor() {
        this.isConnected = false;
        this.settings = {
            notifyShiftStart: true,
            notifyShiftEnd: true,
            notifyBreakStart: true,
            notifyBreakEnd: true,
            notificationTime: 15
        };
        
        this.initializeElements();
        this.loadSettings();
        this.attachEventListeners();
        this.checkConnection();
    }
    
    initializeElements() {
        this.connectBtn = document.getElementById('connectTelegramBtn');
        this.disconnectBtn = document.getElementById('disconnectTelegramBtn');
        this.saveSettingsBtn = document.getElementById('saveSyncSettings');
        this.syncOptions = document.querySelector('.sync-options');
        this.statusDot = document.querySelector('.status-dot');
        this.statusText = document.querySelector('.status-text');
        
        // Notification checkboxes
        this.notifyShiftStart = document.getElementById('notifyShiftStart');
        this.notifyShiftEnd = document.getElementById('notifyShiftEnd');
        this.notifyBreakStart = document.getElementById('notifyBreakStart');
        this.notifyBreakEnd = document.getElementById('notifyBreakEnd');
        this.notificationTime = document.getElementById('notificationTime');
        this.testNotificationBtn = document.getElementById('testNotificationBtn');
    }
    
    loadSettings() {
        const savedSettings = localStorage.getItem('telegramSyncSettings');
        if (savedSettings) {
            this.settings = JSON.parse(savedSettings);
            this.updateUI();
        }
    }
    
    saveSettings() {
        this.settings = {
            notifyShiftStart: this.notifyShiftStart.checked,
            notifyShiftEnd: this.notifyShiftEnd.checked,
            notifyBreakStart: this.notifyBreakStart.checked,
            notifyBreakEnd: this.notifyBreakEnd.checked,
            notificationTime: parseInt(this.notificationTime.value)
        };
        
        localStorage.setItem('telegramSyncSettings', JSON.stringify(this.settings));
        this.showNotification('Настройки сохранены');
    }
    
    updateUI() {
        // Update checkboxes
        this.notifyShiftStart.checked = this.settings.notifyShiftStart;
        this.notifyShiftEnd.checked = this.settings.notifyShiftEnd;
        this.notifyBreakStart.checked = this.settings.notifyBreakStart;
        this.notifyBreakEnd.checked = this.settings.notifyBreakEnd;
        this.notificationTime.value = this.settings.notificationTime;
        
        // Update connection status
        if (this.isConnected) {
            this.statusDot.classList.add('connected');
            this.statusText.textContent = 'Подключено';
            this.syncOptions.style.display = 'block';
            this.connectBtn.style.display = 'none';
            this.testNotificationBtn.style.display = 'flex';
        } else {
            this.statusDot.classList.remove('connected');
            this.statusText.textContent = 'Не подключено';
            this.syncOptions.style.display = 'none';
            this.connectBtn.style.display = 'flex';
            this.testNotificationBtn.style.display = 'none';
        }
    }
    
    async checkConnection() {
        try {
            const userId = localStorage.getItem('userId');
            if (!userId) {
                console.log('Пользователь не авторизован');
                return;
            }

            const response = await fetch('http://localhost:3000/api/check-connection', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ userId })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            this.isConnected = data.connected;
            this.updateUI();
        } catch (error) {
            console.error('Ошибка проверки подключения:', error);
            this.showNotification('Ошибка проверки подключения к серверу', 'error');
        }
    }

    async connectTelegram() {
        try {
            const userId = localStorage.getItem('userId');
            if (!userId) {
                throw new Error('Пользователь не авторизован');
            }

            // Генерируем уникальный код подключения
            const connectionCode = Math.random().toString(36).substring(2, 8).toUpperCase();
            localStorage.setItem('telegramConnectionCode', connectionCode);

            // Сохраняем код на сервере
            const response = await fetch('http://localhost:3000/api/connect-telegram', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ userId, connectionCode })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            // Исправляем формирование ссылки - убираем @ из имени бота
            const botUsername = 'BiletusBotusbot'; // Убрали @
            const connectUrl = `https://t.me/${botUsername}?start=connect_${connectionCode}`;
            
            // Открываем ссылку в новом окне
            window.open(connectUrl, '_blank');
            
            this.showNotification('Пожалуйста, отправьте код подключения боту: ' + connectionCode);
        } catch (error) {
            console.error('Ошибка подключения к Telegram:', error);
            this.showNotification('Ошибка подключения к Telegram: ' + error.message, 'error');
        }
    }
    
    async disconnectTelegram() {
        try {
            const userId = localStorage.getItem('userId');
            if (!userId) return;

            const response = await fetch('http://localhost:3000/api/disconnect-telegram', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ userId })
            });

            if (response.ok) {
                this.isConnected = false;
                this.updateUI();
                this.showNotification('Отключено от Telegram');
            } else {
                throw new Error('Ошибка отключения');
            }
        } catch (error) {
            console.error('Ошибка отключения от Telegram:', error);
            this.showNotification('Ошибка отключения от Telegram', 'error');
        }
    }

    async sendNotification(message) {
        try {
            const userId = localStorage.getItem('userId');
            if (!userId || !this.isConnected) return;

            const response = await fetch('http://localhost:3000/api/send-notification', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ userId, message })
            });

            if (!response.ok) {
                throw new Error('Ошибка отправки уведомления');
            }
        } catch (error) {
            console.error('Ошибка отправки уведомления:', error);
        }
    }

    attachEventListeners() {
        this.connectBtn.addEventListener('click', () => this.connectTelegram());
        this.disconnectBtn.addEventListener('click', () => this.disconnectTelegram());
        this.saveSettingsBtn.addEventListener('click', () => this.saveSettings());
        this.testNotificationBtn.addEventListener('click', () => this.sendTestNotification());
    }

    async sendTestNotification() {
        const testMessage = '🔔 Тестовое уведомление\n\nЕсли вы видите это сообщение, значит бот успешно подключен к сайту!';
        await this.sendNotification(testMessage);
        this.showNotification('Тестовое уведомление отправлено');
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Добавляем кнопку закрытия
        const closeButton = document.createElement('button');
        closeButton.textContent = '×';
        closeButton.className = 'notification-close';
        closeButton.onclick = () => notification.remove();
        notification.appendChild(closeButton);
        
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    // Проверка авторизации
    if (!localStorage.getItem('isAuthenticated')) {
        window.location.href = 'login.html';
        return;
    }

    // Проверяем наличие userId
    if (!localStorage.getItem('userId')) {
        const userId = 'user_' + Math.random().toString(36).substr(2, 9);
        localStorage.setItem('userId', userId);
    }

    createClouds();
    window.tabManager = new TabManager();
    window.templateManager = new TemplateManager();
    window.scheduleManager = new ScheduleManager();
    window.hallOfFameManager = new HallOfFameManager();
    window.cabinetManager = new CabinetManager();
    window.telegramSync = new TelegramSyncManager();

    // Отображение имени пользователя
    const usernameElement = document.getElementById('username');
    usernameElement.textContent = localStorage.getItem('username') || 'Пользователь';

    // Обработка выхода
    document.getElementById('logoutButton').addEventListener('click', () => {
        localStorage.removeItem('isAuthenticated');
        localStorage.removeItem('username');
        localStorage.removeItem('userId');
        window.location.href = 'login.html';
    });
});

// Chart.js init for metrics tab
function initMetricsCharts() {
  if (typeof Chart === 'undefined') return;
  // Качество
  const qualityCtx = document.getElementById('qualityChart').getContext('2d');
  new Chart(qualityCtx, {
    type: 'line',
    data: {
      labels: ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн'],
      datasets: [{
        label: '% Качества',
        data: [92, 95, 93, 97, 96, 98],
        borderColor: '#4a90e2',
        backgroundColor: 'rgba(74,144,226,0.1)',
        fill: true,
        tension: 0.4,
        pointRadius: 5,
        pointBackgroundColor: '#4a90e2',
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { min: 80, max: 100 } }
    }
  });
  // AHT
  const ahtCtx = document.getElementById('ahtChart').getContext('2d');
  new Chart(ahtCtx, {
    type: 'bar',
    data: {
      labels: ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн'],
      datasets: [{
        label: 'AHT (сек)',
        data: [320, 310, 305, 300, 295, 290],
        backgroundColor: 'rgba(76,175,80,0.7)',
        borderRadius: 8
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { min: 250, max: 350 } }
    }
  });
  // KPI
  const kpiCtx = document.getElementById('kpiChart').getContext('2d');
  new Chart(kpiCtx, {
    type: 'doughnut',
    data: {
      labels: ['Выполнено', 'Осталось'],
      datasets: [{
        label: 'KPI',
        data: [78, 22],
        backgroundColor: ['#ff9800', '#e0e0e0'],
        borderWidth: 0
      }]
    },
    options: {
      responsive: true,
      cutout: '70%',
      plugins: {
        legend: { display: false },
        tooltip: { enabled: true }
      }
    }
  });
}
// Инициализация при переходе на вкладку
const metricsTab = document.querySelector('[data-tab="metrics"]');
if (metricsTab) {
  metricsTab.addEventListener('click', () => {
    setTimeout(initMetricsCharts, 200);
  });
} 